# Hannaford Savings Planner — Android project

This Android Studio project packages the planner's existing HTML app inside a native Android WebView shell. It keeps the planner's browser-local saved state, provides Android's file picker for flyer images/PDFs, and opens web links in the browser.

## Build the APK

**Fastest path: GitHub Actions**
1. Create a GitHub repository and upload the contents of this folder.
2. Push the files to the `main` branch.
3. Open the repository's **Actions** tab and run **Build Android APK** (or let it run after the push).
4. Download the `hannaford-savings-planner-debug-apk` artifact from the workflow run. Extract the ZIP to get `app-debug.apk`.
5. Transfer the APK to your Android phone, open it, and approve installation from that source if Android asks.

**Build locally in Android Studio**
1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 if prompted.
3. Choose **Build → Build APK(s)**. The debug APK will be under `app/build/outputs/apk/debug/`.

## Notes
- This is a debug APK for personal testing, not a Play Store release. A signed release build should be created before publishing.
- The flyer OCR, PDF reader, and optional Supabase sync load their JavaScript libraries from CDNs, so those features need internet access.
- Planner data is stored locally on the device unless Supabase is configured and authenticated. Cross-device sync is optional and has not been live-tested here.
- Deal prices shown in the starter data are illustrative, not live Hannaford prices.
